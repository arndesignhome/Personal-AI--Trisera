# ai_core.py
import webbrowser
import google.generativeai as genai

# Provide your genuine Gemini API Token string inside the quotes below
GEMINI_API_KEY = ""

if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)
    model = genai.GenerativeModel('gemini-1.5-flash')
else:
    model = None

def ask_gemini_or_search(query):
    """Hits cloud AI APIs, falling back automatically to direct browser queries when keys fail"""
    if model:
        try:
            response = model.generate_content(query)
            if response.text and response.text.strip():
                return response.text
        except Exception:
            pass
    
    search_url = f"https://www.google.com/search?q={query}"
    webbrowser.open(search_url)
    return f"The answer is not defined in my database, so I have searched for '{query}' on Google for you."