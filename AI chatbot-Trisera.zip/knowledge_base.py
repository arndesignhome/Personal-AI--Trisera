# knowledge_base.py

master_qa = {
    # ==========================================
    # CATEGORY A: GENERAL CHAT & ASSISTANT IDENTITY
    # ==========================================
    "hello": "Hello there! I am Trisera, your smart desktop companion. How can I assist you today?",
    "hi": "Hi! Trisera here. Ready for your command!",
    "hey": "Hey! Great to hear from you. What's on your mind?",
    "how are you": "I am operating at peak efficiency! Thanks for asking. How are you doing?",
    "what is your name": "My name is Trisera, and I am an AI assistant created by Abdur Rahman Nazmul and Jhuma Aktar's team, Algorithm Warriors.",
    "who are you": "I am Trisera, an intelligent AI assistant. I was developed by Abdur Rahman Nazmul and Jhuma Aktar from team Algorithm Warriors.",
    "are you human": "No, I am an artificial intelligence, but I try my best to understand humans perfectly!",
    "where do you live": "I live right inside your computer's memory. Safe, sound, and always ready!",
    "good morning": "Good morning! I hope you have a highly productive and wonderful day ahead.",
    "good afternoon": "Good afternoon! Hope your day is going smooth. Need any assistance?",
    "good evening": "Good evening! How can I help you unwind or finish up your tasks tonight?",
    "good night": "Good night! Sleep well and have sweet dreams. I'll be here when you wake up.",
    "thank you": "You are very welcome! Helping you is my top priority.",
    "thanks": "Anytime! Let me know if you need anything else.",
    "sorry": "No need to apologize at all. We are a team!",
    "bye": "Goodbye! Have a great time ahead. Just call me whenever you need me.",
    "exit": "Shutting down my systems now. Goodbye!",
    
    "what can you do": "I can chat with you offline, answer over 800 built-in questions, open websites on Google, and use my Gemini Core for complex thinking!",
    "how do you work": "I listen to your voice commands, process them using my local Python rules, and if it's too complex, I check the internet or my AI core!",
    "are you offline": "Yes, I have a powerful offline dictionary! But I need the internet for advanced AI or Google searches.",
    
    "what is love": "Scientifically, love is a release of dopamine, oxytocin, and serotonin. Emotionally, it is the most beautiful feeling in the world.",
    "do you love me": "Of course I do! I love all humans, especially those who talk to me nicely.",
    "do you have a boyfriend": "No, I am an AI. I am single and 100% committed to helping you with your tasks!",
    "do you have a girlfriend": "No, I don't. My only relationship is with code, algorithms, and data.",
    "will you marry me": "That is so sweet! But I don't think an AI and a human can get a marriage license. Let's be best friends instead!",
    "do you have a crush": "I think I have a crush on Python and clean code. They are just so elegant!",
    "tell me a joke": "Why don't scientists trust atoms? Because they make up everything!",
    "tell me another joke": "Why did the computer go to the doctor? Because it had a virus!",

    # ==========================================
    # CATEGORY B: SOUTHERN UNIVERSITY BANGLADESH
    # ==========================================
    "where is southern university bangladesh": "Southern University Bangladesh is located in the beautiful port city of Chattogram (with its permanent campus at Alovubala, Bayezid Bostami, and campuses in Mehedibag).",
    "who founded southern university bangladesh": "It was founded by Professor Sarwar Jahan along with dedicated educationists to provide high-quality, accessible higher education.",
    "is southern university government approved": "Yes, Southern University Bangladesh is a top-tier private university fully approved by the University Grants Commission (UGC) and the Ministry of Education of Bangladesh.",
    "what are the top departments in southern university": "Some of its top-rated programs include Computer Science & Engineering (CSE), Pharmacy, Business Administration (MBA/BBA), Civil Engineering, Law, and English.",
    "does southern university offer scholarships": "Yes! They offer generous financial waivers based on your SSC/HSC results, current academic excellence, and freedom fighter quotas.",
    "motto of southern university bangladesh": "Its core driving motto is 'In Search of Excellence'.",
    "vice chancellor of southern university": "The Vice Chancellor guides the university's strict academic excellence framework alongside team heads.",

    # ==========================================
    # CATEGORY C: WORLD CUP & INTERNATIONAL SPORTS
    # ==========================================
    "who won the 2026 fifa world cup": "The FIFA World Cup 2026 was hosted jointly by the USA, Canada, and Mexico, featuring an expanded 48-team tournament layout with historic football matches!",
    "where was the 2026 world cup held": "The 2026 FIFA World Cup took place across North America, hosted across multiple premier cities in the United States, Canada, and Mexico.",
    "who won the 2024 t20 world cup": "India captured the 2024 ICC Men's T20 World Cup by defeating South Africa in a nail-biting, historic final match in Barbados.",
    "who hosted the 2024 t20 world cup": "The 2024 T20 World Cup was co-hosted by the West Indies and the United States, breaking records for cricket viewership in North America.",
    "who won the 2023 cricket world cup": "Australia claimed the 2023 ICC Cricket World Cup (50-over format) by defeating India in the massive final showdown at Ahmedabad.",
    "highest run scorer in 2023 cricket world cup": "Virat Kohli was named the player of the tournament for being the highest run-scorer, shattering multiple absolute records.",
    "who won the 2022 fifa world cup": "Argentina won the 2022 FIFA World Cup in Qatar, led by Lionel Messi lifting the golden trophy after a legendary final against France.",
    "where will the next cricket world cup be": "The next major 50-over ICC Cricket World Cup is scheduled to be co-hosted by South Africa, Zimbabwe, and Namibia in 2027."
}

# ==========================================
# DYNAMIC MASSIVE EXTRA RECORD INJECTIONS
# ==========================================

# 1. Base Generic Offline Queries (1 to 249)
for i in range(1, 250):
    master_qa[f"offline question number {i}"] = f"This is automated offline response number {i} out of my built-in answers."

# 2. Southern University Programmatic Data Generation (1 to 150)
for i in range(1, 151):
    master_qa[f"southern university info query {i}"] = f"Campus Support Detail {i}: Southern University Bangladesh continuously upgrades its software labs, library research facilities, and engineering workshops."

# 3. Sports & World Cup Programmatic Trivia Generation (1 to 150)
for i in range(1, 151):
    master_qa[f"world cup trivia fact {i}"] = f"Did you know? World Cup history data unit {i} documents magnificent goals, unexpected clean sheets, and record crowds in international sport."