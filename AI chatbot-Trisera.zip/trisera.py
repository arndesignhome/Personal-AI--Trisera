# trisera.py
import sys
import webbrowser
import threading
import tkinter as tk
import customtkinter as ctk
import speech_recognition as sr

# Import core background systems
from voice_engine import speech_queue
from ai_core import ask_gemini_or_search
from knowledge_base import master_qa

WAKE_WORD = "nova"

def get_response(text):
    text = text.lower().strip()

    if WAKE_WORD not in text:
        return None

    command = text.replace(WAKE_WORD, "", 1).strip()

    if command == "":
        return "Yes? I am listening."

    clean_command = command.replace("'", "").replace("?", "").replace("!", "")
    
    if clean_command.startswith("whats "):
        clean_command = clean_command.replace("whats ", "what is ", 1)
    if " whats " in clean_command:
        clean_command = clean_command.replace(" whats ", " what is ")

    # PRIORITY 1: Creators and Team Routing Logic
    if "abdur rahman" in clean_command or "abur rahman" in clean_command or "nazmul" in clean_command:
        webbrowser.open("https://www.facebook.com/abdurrahman.naznul")
        return "Abdur Rahman Nazmul is the brilliant lead developer who created me! I am re-directing you to his Facebook profile right now. [Action: Opening Facebook]"

    if "jhuma" in clean_command or "juma" in clean_command or "algorithm warrior" in clean_command:
        return "Jhuma Aktar is the core development partner of Abdur Rahman Nazmul. Together, they formed team Algorithm Warriors to create this Trisera AI!"

    if "who made" in clean_command or "who make" in clean_command or "who created you" in clean_command or "who built you" in clean_command:
        webbrowser.open("https://www.facebook.com/abdurrahman.naznul")
        return "I was made by Abdur Rahman Nazmul and his development partner Jhuma Aktar from team Algorithm Warriors! Let me open Abdur Rahman's Facebook profile for you. [Action: Opening Facebook]"

    # PRIORITY 2: Match within our global offline dictionary
    for key in master_qa:
        if key in clean_command or clean_command in key:
            return master_qa[key]

    # PRIORITY 3: Fallback onto Online Cloud Gemini Core / Google Search Web-scraping
    return ask_gemini_or_search(command)


class TriseraGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Trisera - AI Desktop Assistant")
        self.geometry("550x650")
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        # Top Bar/Status Layout
        self.status_frame = ctk.CTkFrame(self, corner_radius=10)
        self.status_frame.pack(fill="x", padx=15, pady=10)

        self.status_label = ctk.CTkLabel(
            self.status_frame, 
            text=f"Trisera is Active • Say '{WAKE_WORD}' to trigger", 
            font=("Arial", 14, "bold"),
            text_color="#1f538d"
        )
        self.status_label.pack(pady=10)

        # Chat Logging Interface
        self.chat_frame = ctk.CTkFrame(self, corner_radius=10)
        self.chat_frame.pack(fill="both", expand=True, padx=15, pady=5)

        self.chat_box = ctk.CTkTextbox(self.chat_frame, font=("Times New Roman", 15), wrap="word")
        self.chat_box.pack(fill="both", expand=True, padx=10, pady=10)
        self.chat_box.configure(state="disabled")

        # Text input tray controls
        self.input_frame = ctk.CTkFrame(self, height=60, corner_radius=10)
        self.input_frame.pack(fill="x", padx=15, pady=10)

        self.entry_box = ctk.CTkEntry(
            self.input_frame, 
            placeholder_text=f"Type command here (e.g., {WAKE_WORD} hello)...", 
            font=("Arial", 13)
        )
        self.entry_box.pack(side="left", fill="x", expand=True, padx=10, pady=10)
        self.entry_box.bind("<Return>", self.process_keyboard_input)

        self.send_btn = ctk.CTkButton(
            self.input_frame, 
            text="Send", 
            width=80, 
            command=self.process_keyboard_input,
            font=("Arial", 12, "bold")
        )
        self.send_btn.pack(side="right", padx=10, pady=10)

        self.append_chat("Trisera", f"Systems online. Voice active on wake-word '{WAKE_WORD}'. Memory initialized with {len(master_qa)} combined offline responses.")
        
        self.is_listening = True
        self.voice_thread = threading.Thread(target=self.listen_voice_loop, daemon=True)
        self.voice_thread.start()

    def append_chat(self, sender, text):
        self.chat_box.configure(state="normal")
        self.chat_box.insert(tk.END, f"{sender}: {text}\n\n")
        self.chat_box.see(tk.END)
        self.chat_box.configure(state="disabled")

    def update_status(self, text, color="#1f538d"):
        self.status_label.configure(text=text, text_color=color)

    def process_command_flow(self, user_text):
        self.append_chat("You", user_text)
        response = get_response(user_text)
        if response:
            self.append_chat("Trisera", response)
            speech_queue.put(response)
            if "exit" in user_text.lower():
                self.after(2000, sys.exit)

    def process_keyboard_input(self, event=None):
        user_text = self.entry_box.get().strip()
        if user_text:
            self.entry_box.delete(0, tk.END)
            if not user_text.lower().startswith(WAKE_WORD.lower()):
                user_text = f"{WAKE_WORD} {user_text}"
            self.process_command_flow(user_text)

    def listen_voice_loop(self):
        recognizer = sr.Recognizer()
        recognizer.dynamic_energy_threshold = True
        
        with sr.Microphone() as source:
            recognizer.adjust_for_ambient_noise(source, duration=1)
            
            while self.is_listening:
                try:
                    self.update_status("Listening... 🎙️", "#2cc980")
                    audio = recognizer.listen(source, timeout=None, phrase_time_limit=7)
                    
                    self.update_status("Processing Voice...", "#e6a15c")
                    user_speech = recognizer.recognize_google(audio)
                    
                    if WAKE_WORD.lower() in user_speech.lower():
                        self.after(0, self.process_command_flow, user_speech)
                        
                except sr.UnknownValueError:
                    pass
                except sr.RequestError:
                    self.after(0, self.append_chat, "System", "Error: Speech Recognition infrastructure unreachable.")
                except Exception as e:
                    print(f"Voice Loop Exception Tracker: {e}")
                finally:
                    self.update_status(f"Trisera is Active • Say '{WAKE_WORD}' to trigger", "#1f538d")


if __name__ == "__main__":
    app = TriseraGUI()
    app.mainloop()