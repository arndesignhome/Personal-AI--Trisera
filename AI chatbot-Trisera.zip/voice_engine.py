# voice_engine.py
import re
import queue
import time
import threading
import pyttsx3

speech_queue = queue.Queue()

def speak_worker():
    """Independent daemon thread running pyttsx3 instances sequentially safely"""
    while True:
        text = speech_queue.get()
        if text is None:
            break
        try:
            # Drop structural bracket context tokens from vocal delivery
            clean_text = re.sub(r'\[.*?\]', '', text).strip()
            if clean_text:
                engine = pyttsx3.init()
                engine.setProperty('rate', 175)
                engine.setProperty('volume', 0.9)
                
                voices = engine.getProperty('voices')
                if len(voices) > 1:
                    engine.setProperty('voice', voices[1].id)  # Feminine accent preset
                
                engine.say(clean_text)
                engine.runAndWait()
                del engine
        except Exception as e:
            print(f"TTS Engine Loop Failure: {e}")
        finally:
            speech_queue.task_done()
            time.sleep(0.1)

# Automate startup of background processing thread upon module import
threading.Thread(target=speak_worker, daemon=True).start()